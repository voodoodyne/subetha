
SortableTable.prototype.addSortType("LocaleCompare", null, function (s1, s2) {
  return s1.localeCompare(s2);
});
